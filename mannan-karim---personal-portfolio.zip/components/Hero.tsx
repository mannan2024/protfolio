
import React from 'react';
import { personalInfo, professionalLinks, contactInfo } from '../constants';
import { GoogleScholarIcon, OrcidIcon, ResearchGateIcon, MailIcon, PhoneIcon } from './icons/Icons';

const Hero: React.FC = () => {
    return (
        <section className="bg-slate-800 py-20 sm:py-24">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center text-center md:text-left">
                <div className="mb-8 md:mb-0 md:mr-12 flex-shrink-0">
                    <img
                        className="h-48 w-48 rounded-full object-cover mx-auto ring-4 ring-sky-500"
                        src="https://picsum.photos/seed/mannan-karim/200/200"
                        alt="Mannan Karim"
                    />
                </div>
                <div>
                    <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight">
                        {personalInfo.name}
                    </h1>
                    <p className="mt-2 text-xl sm:text-2xl font-medium text-sky-400">
                        {personalInfo.title}
                    </p>
                    <div className="mt-6 flex justify-center md:justify-start space-x-6">
                        <a href={professionalLinks.googleScholar} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-sky-400 transition-colors duration-300">
                            <span className="sr-only">Google Scholar</span>
                            <GoogleScholarIcon />
                        </a>
                        <a href={professionalLinks.orcid} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-sky-400 transition-colors duration-300">
                            <span className="sr-only">ORCID</span>
                            <OrcidIcon />
                        </a>
                        <a href={professionalLinks.researchGate} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-sky-400 transition-colors duration-300">
                            <span className="sr-only">ResearchGate</span>
                            <ResearchGateIcon />
                        </a>
                    </div>
                     <div className="mt-4 flex flex-col sm:flex-row sm:space-x-6 space-y-2 sm:space-y-0 items-center justify-center md:justify-start text-slate-400">
                        <div className="flex items-center">
                            <MailIcon />
                            <a href={`mailto:${contactInfo.email1}`} className="ml-2 hover:text-sky-400 transition-colors duration-300">{contactInfo.email1}</a>
                        </div>
                         <div className="flex items-center">
                            <PhoneIcon />
                            <a href={`tel:${contactInfo.phone1.replace(/\s/g, '')}`} className="ml-2 hover:text-sky-400 transition-colors duration-300">{contactInfo.phone1}</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Hero;
