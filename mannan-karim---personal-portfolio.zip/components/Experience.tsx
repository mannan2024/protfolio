
import React from 'react';
import { educationHistory, researchProjects } from '../constants';
import { LinkIcon } from './icons/Icons';

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">{children}</h2>
);

const Experience: React.FC = () => {
    return (
        <section id="experience" className="py-16 sm:py-20">
            <SectionTitle>Experience & Education</SectionTitle>
            <div className="mt-12">
                <h3 className="text-2xl font-bold text-white mb-8">Education</h3>
                <div className="relative border-l-2 border-slate-700">
                    {educationHistory.map((edu, index) => (
                        <div key={index} className="mb-10 ml-6">
                            <span className="absolute flex items-center justify-center w-6 h-6 bg-sky-500 rounded-full -left-3 ring-8 ring-slate-900">
                                <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd"></path></svg>
                            </span>
                            <h4 className="flex items-center mb-1 text-xl font-semibold text-white">
                                {edu.degree}
                                {edu.degree.includes("Ongoing") && <span className="bg-sky-500 text-white text-sm font-medium mr-2 px-2.5 py-0.5 rounded ml-3">Ongoing</span>}
                            </h4>
                            <p className="text-lg font-medium text-slate-400">{edu.institution}</p>
                            <time className="block my-1 text-sm font-normal leading-none text-slate-500">{edu.duration}</time>
                            <p className="text-sm text-slate-500">{edu.city}, {edu.country}</p>
                            <a href={edu.website} target="_blank" rel="noopener noreferrer" className="inline-flex items-center mt-2 text-sky-400 hover:text-sky-300">
                                Visit Website <LinkIcon />
                            </a>
                        </div>
                    ))}
                </div>
            </div>
            <div className="mt-12">
                <h3 className="text-2xl font-bold text-white mb-8">Research Projects</h3>
                 {researchProjects.map((project, index) => (
                    <div key={index} className="bg-slate-800 rounded-lg p-6 shadow-lg">
                        <p className="text-sm text-slate-400 mb-2">{project.date}</p>
                        <h4 className="text-xl font-bold text-white mb-2">{project.title}</h4>
                        <p className="text-slate-400 whitespace-pre-line leading-relaxed">{project.description}</p>
                        <p className="text-sm text-slate-500 mt-4">{project.supervisor}</p>
                        <a href={project.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center mt-4 font-medium text-sky-400 hover:text-sky-300">
                            View Project Publication <LinkIcon />
                        </a>
                    </div>
                 ))}
            </div>
        </section>
    );
};

export default Experience;
