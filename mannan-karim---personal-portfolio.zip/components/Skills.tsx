
import React from 'react';
import { skills } from '../constants';

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">{children}</h2>
);

const Skills: React.FC = () => {
    return (
        <section id="skills" className="py-16 sm:py-20">
            <SectionTitle>Skills</SectionTitle>
            <div className="mt-8 flex flex-wrap gap-3">
                {skills.map((skill, index) => (
                    <span
                        key={index}
                        className="inline-block bg-slate-800 text-sky-400 text-sm font-medium px-4 py-2 rounded-full shadow-md hover:bg-slate-700 transition-colors duration-300"
                    >
                        {skill}
                    </span>
                ))}
            </div>
        </section>
    );
};

export default Skills;
