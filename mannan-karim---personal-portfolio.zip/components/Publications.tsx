
import React from 'react';
import { publications } from '../constants';
import { LinkIcon } from './icons/Icons';

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">{children}</h2>
);

const Publications: React.FC = () => {
    return (
        <section id="publications" className="py-16 sm:py-20">
            <SectionTitle>Publications</SectionTitle>
            <div className="mt-12 space-y-10">
                {publications.map((pub, index) => (
                    <div key={index} className="bg-slate-800 rounded-lg p-6 shadow-lg transition-transform transform hover:-translate-y-1">
                        <p className="text-sm font-semibold text-sky-400 mb-2">{pub.year}</p>
                        <h3 className="text-xl font-bold text-white mb-2">{pub.title}</h3>
                        <p className="text-slate-400 italic mb-3">{pub.authors}</p>
                        <p className="text-slate-500">{pub.details}</p>
                        {pub.link && (
                             <a href={pub.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center mt-4 font-medium text-sky-400 hover:text-sky-300">
                                View Publication <LinkIcon />
                            </a>
                        )}
                    </div>
                ))}
            </div>
        </section>
    );
};

export default Publications;
