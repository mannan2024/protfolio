
import React, { useState } from 'react';
import { certifications, awards, conferences } from '../constants';
import { LinkIcon } from './icons/Icons';

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">{children}</h2>
);

type Tab = 'certifications' | 'awards' | 'conferences';

const Accomplishments: React.FC = () => {
    const [activeTab, setActiveTab] = useState<Tab>('certifications');

    const TabButton: React.FC<{ tabName: Tab; label: string }> = ({ tabName, label }) => (
        <button
            onClick={() => setActiveTab(tabName)}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors duration-300 ${
                activeTab === tabName ? 'bg-sky-500 text-white' : 'text-slate-300 hover:bg-slate-700'
            }`}
        >
            {label}
        </button>
    );

    const renderContent = () => {
        switch (activeTab) {
            case 'certifications':
                return certifications.map((cert, index) => (
                    <div key={index} className="py-4">
                        <p className="text-sm text-slate-500">{cert.date}</p>
                        <h4 className="font-semibold text-white">{cert.title}</h4>
                        <p className="text-slate-400">{cert.issuer}</p>
                        <a href={cert.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center mt-1 text-sm text-sky-400 hover:text-sky-300">
                            View Certificate <LinkIcon />
                        </a>
                    </div>
                ));
            case 'awards':
                return awards.map((award, index) => (
                    <div key={index} className="py-4">
                        <p className="text-sm text-slate-500">{award.date}</p>
                        <h4 className="font-semibold text-white">{award.title}</h4>
                        <p className="text-slate-400">{award.issuer}</p>
                        <a href={award.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center mt-1 text-sm text-sky-400 hover:text-sky-300">
                            More Info <LinkIcon />
                        </a>
                    </div>
                ));
            case 'conferences':
                return conferences.map((conf, index) => (
                     <div key={index} className="py-4">
                        <p className="text-sm text-slate-500">{conf.date}</p>
                        <h4 className="font-semibold text-white">{conf.title}</h4>
                        <p className="text-slate-400">{conf.location}</p>
                         {conf.link && (
                             <a href={conf.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center mt-1 text-sm text-sky-400 hover:text-sky-300">
                                More Info <LinkIcon />
                            </a>
                         )}
                    </div>
                ));
            default:
                return null;
        }
    };

    return (
        <section id="accomplishments" className="py-16 sm:py-20">
            <SectionTitle>Accomplishments</SectionTitle>
            <div className="mt-8">
                <div className="flex space-x-2 border-b border-slate-700 mb-4">
                    <TabButton tabName="certifications" label="Certifications" />
                    <TabButton tabName="awards" label="Honors & Awards" />
                    <TabButton tabName="conferences" label="Conferences" />
                </div>
                <div className="divide-y divide-slate-800">
                    {renderContent()}
                </div>
            </div>
        </section>
    );
};

export default Accomplishments;
