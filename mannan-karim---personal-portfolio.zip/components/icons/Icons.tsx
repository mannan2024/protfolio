
import React from 'react';

export const GoogleScholarIcon: React.FC = () => (
    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
        <path d="M12 24c5.523 0 10-4.477 10-10S17.523 4 12 4 2 8.477 2 14s4.477 10 10 10zM5.38 11.458L12 8.243l6.62 3.215L12 14.673 5.38 11.458zM12 15.827l4.42-2.14V17l-4.42 2.14-4.42-2.14v-3.313L12 15.827z"></path>
    </svg>
);

export const OrcidIcon: React.FC = () => (
    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
        <path d="M12 24c6.627 0 12-5.373 12-12S18.627 0 12 0 0 5.373 0 12s5.373 12 12 12zM8.51 5.923c.538 0 .977.438.977.977s-.439.977-.977.977-.977-.438-.977-.977.439-.977.977-.977zM7.53 8.9h2v8.174h-2V8.9zm4.24 2.87c2.31 0 3.73 1.343 3.73 3.65v1.654h-2V15.2c0-1.157-.74-1.846-1.92-1.846-1.25 0-1.81.79-1.81 1.81v3.313h-2V8.9h1.94v1.44s.8-1.44 2.06-1.44z"></path>
    </svg>
);

export const ResearchGateIcon: React.FC = () => (
    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
       <path d="M21.31 16.59L15.34 4.66a2.64 2.64 0 00-4.66 0L4.69 16.59a2.64 2.64 0 002.33 3.96h9.96a2.64 2.64 0 002.33-3.96zM12 15.34h-2v-4h2v4z"></path>
    </svg>
);

export const MailIcon: React.FC = () => (
    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
    </svg>
);

export const PhoneIcon: React.FC = () => (
    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
    </svg>
);

export const LinkIcon: React.FC = () => (
     <svg className="w-4 h-4 ml-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
    </svg>
);
