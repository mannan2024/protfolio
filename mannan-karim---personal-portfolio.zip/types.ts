
export interface ContactInfo {
    phone1: string;
    phone2: string;
    email1: string;
    email2: string;
    wechat: string;
    qq: string;
    whatsapp: string;
    address: string;
}

export interface ProfessionalLinks {
    googleScholar: string;
    orcid: string;
    researchGate: string;
}

export interface Education {
    degree: string;
    institution: string;
    duration: string;
    city: string;
    country: string;
    website: string;
    details?: string;
}

export interface ResearchInterest {
    text: string;
}

export interface Publication {
    year: string;
    title: string;
    authors: string;
    details: string;
    link?: string;
}

export interface ResearchProject {
    date: string;
    title: string;
    description: string;
    supervisor: string;
    link: string;
}

export interface Certification {
    date: string;
    title: string;
    issuer: string;
    link: string;
}

export interface Award {
    date: string;
    title: string;
    issuer: string;
    link: string;
}

export interface Conference {
    date: string;
    title: string;
    location: string;
    link?: string;
}

export interface Language {
    name: string;
    motherTongue?: boolean;
    listening: string;
    reading: string;
    writing: string;
    spokenProduction: string;
    spokenInteraction: string;
}

export interface Recommendation {
    name: string;
    role: string;
    email: string;
    phone: string;
    link: string;
}
