
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Experience from './components/Experience';
import Publications from './components/Publications';
import Accomplishments from './components/Accomplishments';
import Recommendations from './components/Recommendations';
import Footer from './components/Footer';

const App: React.FC = () => {
    return (
        <div className="min-h-screen bg-slate-900 font-sans leading-relaxed">
            <Header />
            <main>
                <Hero />
                <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                    <About />
                    <Skills />
                    <Experience />
                    <Publications />
                    <Accomplishments />
                    <Recommendations />
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default App;
