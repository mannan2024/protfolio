
import { 
    ContactInfo, 
    ProfessionalLinks, 
    Education, 
    ResearchInterest, 
    Publication,
    ResearchProject,
    Certification,
    Award,
    Conference,
    Language,
    Recommendation 
} from './types';

export const personalInfo = {
    name: "Mannan Karim",
    title: "Remote Sensing & Deep Learning Researcher",
    nationality: "Pakistani",
    dob: "10 Apr 1998"
};

export const contactInfo: ContactInfo = {
    phone1: "(+86) 15951986786",
    phone2: "(+92) 3054683546",
    email1: "mannankarimayo1991@gmail.com",
    email2: "202451110006@nuist.edu.cn",
    wechat: "LHR4683546",
    qq: "3362297632",
    whatsapp: "+923054683546",
    address: "Room 2702, Building 4, Shanju Garden and Yuan, Lukun District, Nanjing City, 211800 Nanjing (China)"
};

export const professionalLinks: ProfessionalLinks = {
    googleScholar: "https://scholar.google.com/citations?user=m_7oINIAAAAJ&hl=en",
    orcid: "https://orcid.org/0009-0006-7823-1660",
    researchGate: "https://www.researchgate.net/profile/Mannan-Karim-2"
};

export const aboutMe: string = "I am a remote sensing researcher, utilizes deep learning to perform semantic segmentation and image classification for vegetation and land use change detection, multi-sensor shadow detection and feature extraction. I am proficient in Python, Google Earth Engine, ENVI and ArcGIS Pro. I have published in peer reviewed journals and collaborated across disciplines. I work well both independently and as part of cross-national teams, and I am committed to applying deep learning and remote sensing to support environmental sustainability and biodiversity monitoring.";

export const educationHistory: Education[] = [
    {
        degree: "PhD (Ongoing)",
        institution: "School of Remote Sensing and Geomatics Engineering, NUIST",
        duration: "1 Sep 2024 – Current",
        city: "Nanjing",
        country: "China",
        website: "https://www.nuist.edu.cn/main.htm"
    },
    {
        degree: "Master in Land Resources and Information Engineering",
        institution: "School of Geoscience and Info-Physics, Central South University",
        duration: "1 Sep 2020 – 30 Jun 2024",
        city: "Changsha",
        country: "China",
        website: "https://en.csu.edu.cn/",
        details: "Level in EQF: EQF level 1"
    },
    {
        degree: "Bachelor",
        institution: "Department of Space Science, University of the Punjab, Lahore",
        duration: "12 Oct 2015 – 10 Sep 2019",
        city: "Lahore",
        country: "Pakistan",
        website: "https://pu.edu.pk/home/department/62/Department-of-Space-Science"
    }
];

export const researchInterests: ResearchInterest[] = [
    { text: "Developing and applying deep learning to remote sensing data for detecting and mapping vegetation change, land-use conversion, and biodiversity at high spatial resolution." },
    { text: "Integrating satellite, drone, and field (ground-truth) data to improve model accuracy, particularly in vegetation trait estimation, species classification, and ecological monitoring under environmental stressors." },
    { text: "Exploring data-efficient methods (e.g. using fewer labelled samples, self- or semi-supervised learning) to build scalable, interpretable tools that support sustainable land management, conservation, and environmental policy." }
];

export const publications: Publication[] = [
    {
        year: "2024",
        title: "ViT-ChangeFormer: A Deep Learning Approach for Cropland Abandonment Detection in Lahore, Pakistan Using Landsat-8 and Sentinel-2 Data",
        authors: "Karim, M., Guan, H., Zhang, J., Ayoub, M., 2025.",
        details: "Remote Sensing Applications: Society and Environment 37, 101468."
    },
    {
        year: "2023",
        title: "Improved Cropland Abandonment Detection with Deep Learning Vision Transformer (DL-ViT) and Multiple Vegetation Indices.",
        authors: "Karim, M.; Deng, J.; Ayoub, M.; Dong, W.; Zhang, B.; Yousaf, M.S.; Bhutto, Y.A.; Ishfaque, M.",
        details: "Land 2023, 12, 1926",
        link: "https://doi.org/10.3390/land12101926"
    },
    {
        year: "2024",
        title: "SACNet: A Novel Self-Supervised Learning Method for Shadow Detection from High-Resolution Remote Sensing Images",
        authors: "Chen, D., Kang, J., Wang, L., Yu, Y., Zhou, W., Guan, H., Karim, M., 2025.",
        details: "J geovis spat anal 9, 14"
    }
];

export const researchProjects: ResearchProject[] = [
    {
        date: "10 Oct 2022 - 30 Jan 2024",
        title: "Abandoned Farmland Detection and Analysis from Gaofen Images Based on Vision Transformer with Multiple Vegetation Indices",
        description: "This research was funded by the National Natural Science Foundation of China (Grant No. 42172330) and the 2021 Henan Natural Resources Research Project (Grant No. [2021]157-12). The project combined 8-meter multiband Gaofen-6 imagery with multiple vegetation indices (Vls) to improve detection of cropland abandonment in Mianchi County, China. The method used a Vision Transformer (ViT) model to classify land cover, integrating Vls to enhance discrimination between abandoned, cultivated, and uncultivated lands. Results achieved overall accuracy of approximately 94% and F1 scores near 0.89 when all vegetation indices were used. Based on the ViT predictions, about 385 hectares (~2.2%) of cropland were identified as abandoned over 2019-2023. This work contributes to land use management, ecological conservation, and informed decision making for agricultural sustainability.",
        supervisor: "The supervisor for this project was Dr. Jiqiu Deng (csugis@csu.edu.cn)",
        link: "https://doi.org/10.3390/land12101926"
    }
];

export const skills: string[] = [
    "Python", "C++", "Google Earth Engine", "ArcGIS", "ArcGIS Pro", "ENVI 5.6", "QGIS", "Google Earth Pro", "ENVI", "Microsoft Office", "Remote Sensing", "Cartography", "eCognition Software", "Satellite Images Analysis"
];

export const languages: Language[] = [
    { name: "Urdu", motherTongue: true, listening: "Native", reading: "Native", writing: "Native", spokenProduction: "Native", spokenInteraction: "Native" },
    { name: "English", listening: "C2", reading: "C2", writing: "C1", spokenProduction: "C1", spokenInteraction: "C1" },
    { name: "Chinese", listening: "A1", reading: "A1", writing: "A1", spokenProduction: "A1", spokenInteraction: "A1" }
];

export const certifications: Certification[] = [
    { date: "1 Mar 2023 – 6 May 2023", title: "Digital Image Processing with OpenCV in Python", issuer: "Geo University", link: "https://www.geo.university/" },
    { date: "8 Jun 2023 - 4 Jul 2023", title: "Cartography", issuer: "ESRI", link: "https://www.esri.com/training/" },
    { date: "8 Aug 2023 – 9 Aug 2023", title: "Introduction to Geospatial Data Analysis in Python", issuer: "Udemy", link: "https://www.udemy.com/" },
    { date: "2 Mar 2022 – 2 May 2022", title: "Going Places with Spatial Analysis", issuer: "ESRI", link: "https://www.esri.com/training" },
    { date: "5 Jan 2022 - 6 Mar 2022", title: "Remote Sensing and Satellite Image Processing with the EOS Platform", issuer: "Geo University", link: "https://www.geo.university/" },
    { date: "6 Aug 2022 – 3 Sep 2022", title: "Remote Sensing Applications using the Hellenic National Sentinel Data Mirror Site", issuer: "Geo University", link: "https://www.geo.university/" },
];

export const awards: Award[] = [
    { date: "9 Jan 2024", title: "Awardee of Chinese Government Scholarship for PhD.", issuer: "Nanjing University of Information Science and Technology", link: "https://www.chinesescholarshipcouncil.com/" },
    { date: "1 Aug 2020", title: "Awardee of Central South University Scholarship", issuer: "Central South University, China", link: "https://en.csu.edu.cn/" },
    { date: "10 Sep 2015", title: "PEEF (Punjab Educational Endowment Fund) Scholar", issuer: "University of the Punjab, Lahore", link: "https://www.peef.org.pk/" },
];

export const conferences: Conference[] = [
    { date: "1 Jul 2024", title: "Wang Jianxin's Team from the School of Computer Science and Engineering Achieves New Progress in Research of Genome Transposon Detection and Annotation", location: "Changsha", link: "https://en.csu.edu.cn/info/1085/2927.htm" },
    { date: "6 Dec 2023", title: "Ranjith Pathegama Gamage, Honorary Professor at Central South University, Elected as Foreign Academician of the Chinese Academy of Engineering", location: "Changsha", link: "https://en.csu.edu.cn/info/1085/2832.htm" },
    { date: "15 Jan 2017 - 16 Jan 2017", title: "Conference proceeding on Detection and geolocation of services onboard lightning nano satellite (LINSAT)", location: "Lahore, Pakistan" },
    { date: "9 Jun 2015 – 11 Jun 2015", title: "Conference proceeding on Space outreach initiatives through online & real time space operations using virtual ground station", location: "Lahore" },
];

export const recommendations: Recommendation[] = [
    { name: "Jiqiu Deng", role: "Master's Supervisor", email: "csugis@csu.edu.cn", phone: "(+86) 13874950729", link: "https://faculty.csu.edu.cn/dengjiqiu/en/index.htm" },
    { name: "Zhang Baoyi", role: "Instructor", email: "zhangbaoyi@csu.edu.cn", phone: "(+86) 073188877676", link: "https://faculty.csu.edu.cn/zhangbaoyi/en/index.htm" },
    { name: "Syed Amer Mahmood", role: "Bachelor Supervisor", email: "imamer@spsc.pu.edu.pk", phone: "(+92) 324988081", link: "https://pu.edu.pk/faculty/expe/577" }
];
